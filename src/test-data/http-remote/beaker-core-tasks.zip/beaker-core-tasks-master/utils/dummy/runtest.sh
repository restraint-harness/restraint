#!/bin/bash

. /usr/bin/rhts_environment.sh

report_result ${TEST} PASS 0
exit 0

